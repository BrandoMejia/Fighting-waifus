﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortraitInfo : MonoBehaviour
{
    public int posX;
    public int posY;
    public string characterId;
}
